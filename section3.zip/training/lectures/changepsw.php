<?php
  include '../inc/connection.php';
  session_start();

  if (!$_SESSION['email']){
    header("location: login.php");
  }


  if (isset($_POST['lect_login'])){

      $old_psw = $_POST['old_psw'];
      $new_pass = $_POST['new_pass'];
      $cpsw = $_POST['cpsw'];

      $sql = $db->query("SELECT * FROM lecture WHERE l_email='".$_SESSION['email']."' AND psw='$old_psw'");
      $check = mysqli_num_rows($sql);
      $row = mysqli_fetch_assoc($sql);
     }

 ?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>CHANGE PASSWORD</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet"> -->

	<!-- Animate.css -->
	<link rel="stylesheet" href="../css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="../css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="../css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="../css/style.css">

	<!-- Modernizr JS -->
	<script src="../js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
  <style media="screen">
    li a{
      color: #000;
    }
		h3{
			text-align: center;
			text-transform: uppercase;
			color: #c3c3c3;
		}
  </style>
	</head>
	<body>

    <div class="gtco-loader"></div>

  	<div id="page">
  	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			<div class="row">
			</div>
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.html">
						<img src="../images/jstack.png" alt="Logo">
						 </a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li><a href="index.php" style="color: #000">Home</a></li>
						<li><a href="mystd.php" style="color: #000">My Students</a></li>
						<li><a href="addstd.php" style="color: #000">Add Student</a></li>
						<li><a href="changepsw.php" style="color: #000">Change Password</a></li>
						<li><a href="logout.php" style="color: #000"><i class="ti-pencil-alt">Logout</i></a></li>
					</ul>
				</div>
			</div>

		</div>
	</nav>


  <?php
    $user = $_SESSION['email']; // GET USER ID
    $sql = $db->query("SELECT * FROM lecture WHERE l_email='$user'"); // GET THE LECTURE INFO
    $row = mysqli_fetch_assoc($sql);
    $check = mysqli_num_rows($sql); // CHECK TO SEE IF LECTURE IS REGISTRED INSIDE DATABASE
    if (isset($_POST['lect_login'])){
      $o_pass = $row['psw'];
      if ($check == "1"){ // IF LECTURE EXISTS
        if ($_POST['old_psw'] == $row['psw']){ // VALIDATE BOTH PASSWORDS
          echo "<script>alert('Old password, login password dont match. Please try again.')</script>";
        }else if ($_POST['new_pass'] != $_POST['cpsw']){
          echo "<script>alert('Passwords dont match')</script>";
        }else{
          $hh = $row['id'];
          // ENCRYPT AND UPDATE PASSWORD
          $change = $db->query("UPDATE lecture SET psw='".md5($_POST['new_pass'])."' WHERE id='$hh'");
          if ($change){
          echo "<script>alert('Password has been successfully updated.')</script>"; // SHOW SUCCESS MESSAGE
        }else{
          echo "<script>alert('Unable to update password.')</script>"; // ELSE THROW ERROR
          echo mysqli_error($db);
        }
      }
    }
  }


   ?>





	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row row-pb-md">
				<div class="col-md-12 animate-box">
					<h3>UPDATE PASSWORD</h3>
					<form action="changepsw.php" method="post">

						<div class="row form-group">
							<div class="col-md-12">
								<label class="sr-only" for="email">Email</label>
								<input type="password" id="email" name="old_psw"
                class="form-control" placeholder="Old Password">
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label class="sr-only" for="email">Email</label>
								<input type="password" id="email" name="new_pass"
                class="form-control" placeholder="Choose new password">
							</div>
						</div>


						<div class="row form-group">
							<div class="col-md-12">
								<label class="sr-only" for="subject">Choose Password</label>
								<input type="password" id="psw" name="cpsw"
                class="form-control" placeholder="Confirm password">
							</div>
						</div>

						<div class="form-group">
							<p align="center">
								<input type="submit" name="lect_login" value="Login" class="btn btn-primary btn-lg">
							</p>
						</div>

					</form>
				</div>
			</div>
			</div>

		</div>
	</div>

	<!-- jQuery -->
	<script src="../js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="../js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="../js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="../js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="../js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="../js/main.js"></script>

	</body>
</html>
