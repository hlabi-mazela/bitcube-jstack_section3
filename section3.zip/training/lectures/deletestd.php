<?php 
	include '../inc/connection.php';
	$id = $_GET['id'];
	$sql = $db->query("DELETE FROM student WHERE id='$id'");
	header("location: mystd.php");
 ?>