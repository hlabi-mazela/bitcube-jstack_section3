-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2021 at 09:51 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `training`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `admin_pnum` text NOT NULL,
  `added_by` varchar(20) NOT NULL,
  `admin_pass` text NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `admin_email`, `gender`, `admin_pnum`, `added_by`, `admin_pass`, `status`) VALUES
(1, 'Hlabi Mazela', 'hlabi@gmail.com', 'Male', '000 000 0000', 'hlabi@gmail.com', '5b7f411f47d34cd282bf6ae6ef426b0f', 'hlabi');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `degree_name` varchar(150) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `duration` int(11) NOT NULL,
  `lecture` text NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `degree_name`, `course_name`, `duration`, `lecture`, `status`) VALUES
(1, 'Diploma in Software Development', 'DISD', 6, 'Hlabi Mazela', 'hlabi'),
(2, 'Diploma in Software Development', 'Programming 1A,\r\nProgramming logic and design,\r\nBusiness Studies,\r\nComputer Networking', 4, 'Hlabi Mazela', 'hlabi');

-- --------------------------------------------------------

--
-- Table structure for table `degree`
--

CREATE TABLE `degree` (
  `id` int(11) NOT NULL,
  `degree_name` varchar(100) NOT NULL,
  `duration` int(11) NOT NULL,
  `course` text NOT NULL,
  `lecture` varchar(100) NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `degree`
--

INSERT INTO `degree` (`id`, `degree_name`, `duration`, `course`, `lecture`, `status`) VALUES
(1, 'Bachelor of Commerce in Law', 4, 'DISD', 'Hlabi Mazela', 'hlabi'),
(2, 'Diploma in Software Development', 3, 'DISD', 'Hlabi Mazela', 'hlabi');

-- --------------------------------------------------------

--
-- Table structure for table `lecture`
--

CREATE TABLE `lecture` (
  `id` int(11) NOT NULL,
  `l_names` varchar(150) NOT NULL,
  `l_lname` varchar(100) NOT NULL,
  `l_email` varchar(100) NOT NULL,
  `pnum` varchar(15) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `course_responsible` text NOT NULL,
  `dob` text NOT NULL,
  `date_insert` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `psw` text NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecture`
--

INSERT INTO `lecture` (`id`, `l_names`, `l_lname`, `l_email`, `pnum`, `gender`, `course_responsible`, `dob`, `date_insert`, `psw`, `status`) VALUES
(1, 'Hlabi', 'Mazela', 'hlabi@gmail.com', '000 000 0000', 'Male', 'Diploma in Software Development', '1992-06-09', '2021-03-17 14:18:13', '5b7f411f47d34cd282bf6ae6ef426b0f', 'hlabi'),
(2, 'Naledi', 'Masemola', 'nale@gmail.com', '000 000 0000', 'Female', 'Diploma in Software Development', '2010-11-25', '2021-03-17 14:19:13', '5b7f411f47d34cd282bf6ae6ef426b0f', 'hlabi');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `user_ip` text NOT NULL,
  `names` varchar(150) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dob` text NOT NULL,
  `qulification` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `user_ip`, `names`, `lname`, `email`, `dob`, `qulification`, `pass`, `reg_date`, `status`) VALUES
(1, '::1', 'Hlabi', 'Mazela', 'hlabi@gmail.com', '2021-03-09', 'Diploma in Software Development', '5b7f411f47d34cd282bf6ae6ef426b0f', '2021-03-17 13:38:43', 'hlabi'),
(2, '::1', 'Naledi', 'Masemola', 'nale@gmail.com', '2017-06-17', 'Diploma in Software Development', '5b7f411f47d34cd282bf6ae6ef426b0f', '2021-03-17 14:21:16', 'hlabi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `degree`
--
ALTER TABLE `degree`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecture`
--
ALTER TABLE `lecture`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `degree`
--
ALTER TABLE `degree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lecture`
--
ALTER TABLE `lecture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
