<?php
  $db = mysqli_connect("localhost","root","","training") // ESTABLISH CONNECTION
  or die("Oops, Unable to contact server. Please try again later"); // OR DISPLAY ERROR

 ?>
