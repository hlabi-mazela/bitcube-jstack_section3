<?php
  include '../inc/connection.php';
  session_start();
  if (!$_SESSION['email']){
    header("location: login.php");
  }

  if (isset($_POST['admin_register'])){ # IF BUTTON IS CLICKED
    # GET FORM DATA
    $admin_name = $_POST['admin_name'];
    $email = $_POST['email'];
    $pnum = $_POST['pnum'];
    $gender = $_POST['gender'];
    $psw = md5($_POST['psw']);
    $status = "hlabi";
    # REGISTER NEW ADMIN
    $sql = $db->query("INSERT INTO admin(admin_name, admin_email, gender,admin_pnum,added_by,admin_pass,status)
    VALUES('$admin_name','$email','$gender','$pnum','".$_SESSION['email']."','$psw','$status')");

    if ($sql){
      echo "<script>alert('Admin added successfully')</script>";
    }else{
      echo "<script>alert('Unable to add admin')</script>";

    }



  }




 ?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>New Admin</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet"> -->

	<!-- Animate.css -->
	<link rel="stylesheet" href="../css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="../css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="../css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="../css/style.css">

	<!-- Modernizr JS -->
	<script src="../js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
  <style media="screen">
    li a{
      color: #000;
    }
		h3{
			text-align: center;
			text-transform: uppercase;
			color: #c3c3c3;
		}
    .multiselect{
      width: auto;
    }
    .selectBox{
      position: relative;
    }
    .selectBox select{
      width: 100%;
      font-weight: 400;
    }
    .overSelect{
      position: absolute;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
    }
    #checkboxes{
      display: none;
      border: 1px #dadada solid
    }
    #checkboxes label{
      display: block;
    }
    #checkboxes label:hover{
      background-color: inherit;
      /* #1e90ff; */
    }
  </style>
	</head>
	<body>

	<div class="gtco-loader"></div>

  	<div id="page">
  	<nav class="gtco-nav" role="navigation">
  		<div class="gtco-container">
  			<div class="row">
  			</div>
  			<div class="row">
  				<div class="col-sm-4 col-xs-12">
  					<div id="gtco-logo"><a href="index.html">
  						<img src="../images/jstack.png" alt="Logo">
  						 </a></div>
  				</div>
  				<div class="col-xs-8 text-right menu-1">
            <ul>
  						<li class="active" style="color:#000;"><a href="index.php">Home</a></li>
  						<li><a href="newlect.php" style="color:#000;">Add Lecture</a></li>
  						<li><a href="alllect.php" style="color:#000;">All Lectures</a></li>
  						<li class="has-dropdown" style="color:#000;">
  							<a href="allstd.php" style="color:#000;">All Student</a>
  							<ul class="dropdown">
  								<li><a href="#">Advanced Certificate</a></li>
  								<li><a href="#">Graduate Certificate</a></li>
  								<li><a href="#">Postgraduation Certificate</a></li>
  							</ul>
  						</li>
  						<li class="has-dropdown">
  							<a href="#" style="color:#000;">Degrees</a>
  							<ul class="dropdown">
  								<li><a href="adddegre.php">Add Degree</a></li>
  								<li><a href="addcourse.php">Add Course</a></li>
  								<li><a href="newadmin.php">Add admin</a></li>
  								<li><a href="#">Online</a></li> -->
  							</ul>
  						</li>
  						<li><a href="#"><i class="ti-user" style="color:#000;">New Admin</i></a></li>
  						<li><a href="logout.php"><i class="ti-pencil-alt" style="color:#000;">Logout</i></a></li>
  					</ul>
  				</div>
  			</div>

  		</div>
  	</nav>








	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row row-pb-md">
				<div class="col-md-12 animate-box">
					<h3>Register Lecture</h3>
					<form action="newadmin.php" method="post">
						<div class="row form-group">
							<div class="col-md-12">
								<label class="sr-only" for="name">Name And Surname</label>
								<input type="text" id="name" name="admin_name" class="form-control" placeholder="Name And Surname">
							</div>
						</div>
						<div class="row form-group">
							<div class="col-md-12">
								<label class="sr-only" for="name">email</label>
								<input type="email" id="name" name="email" class="form-control" placeholder="Admin Email">
							</div>
						</div>
						<div class="row form-group">
							<div class="col-md-12">
								<label class="sr-only" for="subject">Phone Number</label>
								<input type="text" id="psw" name="pnum" placeholder="Phone number..." class="form-control">
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label class="sr-only" id="psw" for="subject">Gender</label>
								<select class="form-control" name="gender">
									<option disabled="">Please pick gender</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
									<option value="Other">I prefer not to say</option>
								</select>
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label class="sr-only" for="subject">Choose Password</label>
								<input type="password" id="psw" name="psw" class="form-control" placeholder="Choose a password">
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label class="sr-only" for="subject">Confirm Password</label>
								<input type="password" id="cpsw" name="cpsw" class="form-control" placeholder="Confirm password">
							</div>
						</div>


						<div class="form-group">
							<p align="center">
								<input type="submit" name="admin_register" value="Register" class="btn btn-primary btn-lg">
							</p>
						</div>

					</form>
				</div>
			</div>
			</div>

		</div>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>

	<!-- jQuery -->
	<script src="../js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="../js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="../js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="../js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="../js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="../js/main.js"></script>
  <script type="text/javascript">
    // Declare variable
    var expanded = false;
    // Add checkbox inside dropdown SELECT OPTION
    function showCheckbox(){
      var checkboxes = document.getElementById("checkboxes");
      if (!expanded){
        checkboxes.style.display = "block";
        expanded = true;
      }else{
        checkboxes.style.display = "none";
        expanded = false;
      }
    }
  </script>


	</body>
</html>

<!-- ffrwd.co.za -->
