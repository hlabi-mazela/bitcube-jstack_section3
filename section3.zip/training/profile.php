<?php
include 'inc/header.php';
  if (isset($_SESSION['email'])){ // CHECK IF USER IS LOGGED IN
    $user = $_SESSION['email'];
  }
?>
<header id="gtco-header" class="gtco-cover" role="banner" style="background-image:url(images/6.jpg);">
	<div class="overlay"></div>
	<div class="gtco-container">
		<div class="row">
			<div class="col-md-12 col-md-offset-0 text-left">
				<div class="display-t">
					<form class="" action="" method="post">
						<div class="display-tc">
							<h1 class="animate-box" data-animate-effect="fadeInUp">BITCUBE INTERNSHIP PROGRAMME</h1>
							<input type="search" name="txtSearch" placeholder="Search for a course here..."
							class="form-control animate-box" data-animate-effect="fadeInUp"><br>
							<input type="submit" name="btnSearch" value="Search" class="btn btn-white btn-lg btn-outline">

						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</header>



  <?php
      $user = $_SESSION['email'];
      $sql = $db->query("SELECT a.names, a.lname, a.email, a.dob, a.qulification,
                                b.l_names, b.l_lname, b.gender
        FROM student a
        INNER JOIN lecture b
        WHERE email='$user'");
      $row = mysqli_fetch_assoc($sql);

   ?>

<div id="gtco-features-3">
  <div class="gtco-container">
    <div class="gtco-flex">
      <div class="feature feature-1 animate-box" data-animate-effect="fadeInUp">
        <div class="feature-inner">
          <span class="icon">
            <i class="ti-arrow-circle-up"></i>
          </span>
          <h3>My Details</h3>
          <p>
            <b>Date of Birth: </b><?php echo $row['dob']; ?>
          </p>
        </div>
      </div>
      <div class="feature feature-2 animate-box" data-animate-effect="fadeInUp">
        <div class="feature-inner">
          <span class="icon">
            <i class="ti-user"></i>
          </span>
          <h1 style="color:#fff; font-weight: bold"><?php echo mb_strtoupper($row['names'])." ".mb_strtoupper($row['lname']); ?></h1>
          <p>
            <?php
              echo "<p>Degree Currently studying</p><br>", "<h3>".$row['qulification']."</h3>";
             ?>
          </p>
        </div>
      </div>
      <div class="feature feature-3 animate-box" data-animate-effect="fadeInUp">
        <div class="feature-inner">
          <span class="icon">
            <i class="ti-hand-point-down"></i>
          </span>
          <h3>Major Lecture</h3>
          <p>
            <?php
              echo $row['l_names']." ".$row['l_lname'];
              echo "<br><b>Gender: </b>".$row['gender'];
             ?>
          </p>
        </div>
      </div>
    </div>
  </div>
</div>




	<footer id="gtco-footer" role="contentinfo">
		<div class="gtco-container">
			<div class="row row-pb-md">

				<div class="col-md-4">
					<div class="gtco-widget">
						<h3>About Us</h3>
						<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore eos molestias quod sint ipsum possimus temporibus officia iste perspiciatis consectetur in fugiat repudiandae cum. Totam cupiditate nostrum ut neque ab?</p>
					</div>
				</div>

				<div class="col-md-4 col-md-push-1">
					<div class="gtco-widget">
						<h3>Links</h3>
						<ul class="gtco-footer-links">
							<li><a href="#">Knowledge Base</a></li>
							<li><a href="#">Career</a></li>
							<li><a href="#">Press</a></li>
							<li><a href="#">Terms of services</a></li>
							<li><a href="#">Privacy Policy</a></li>
						</ul>
					</div>
				</div>

				<div class="col-md-4">
					<div class="gtco-widget">
						<h3>Get In Touch</h3>
						<ul class="gtco-quick-contact">
							<li><a href="#"><i class="icon-phone"></i>000 000 0000</a></li>
							<li><a href="#"><i class="icon-mail2"></i> info@bitcube.com</a></li>
						</ul>
					</div>
				</div>

			</div>

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>
